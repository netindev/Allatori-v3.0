package com.allatori;

import java.util.Vector;

public class Class5 {

    public Vector aVector511;
    public RenamingMap aRenamingMap_512;
    public RenamingMap aRenamingMap_513;
    public RenamingMap aRenamingMap_514;
    public Vector aVector515;
    public RenamingMap aRenamingMap_516;


    public Class5(RenamingMap var1, RenamingMap var2, RenamingMap var3, Vector var4, Vector var5, RenamingMap var6) {
        this.aRenamingMap_512 = var1;
        this.aRenamingMap_514 = var2;
        this.aRenamingMap_516 = var3;
        this.aVector515 = var4;
        this.aVector511 = var5;
        this.aRenamingMap_513 = var6;
    }
}
