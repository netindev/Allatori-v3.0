package com.allatori;

public class Class156 {

    private Interface22 anInterface22_809;


    // $FF: synthetic method
    public Class156(Class172 var1, Class178 var2) {
        this(var1);
    }

    private Class156(Class172 var1) {
        Class172 aClass172_810 = var1;
        this.anInterface22_809 = Unknown.method337();
    }

    // $FF: synthetic method
    public static Interface22 method1603(Class156 var0) {
        return var0.anInterface22_809;
    }
}
