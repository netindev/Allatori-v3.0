package com.allatori;


public class Class180 {

    private static ClassConstraint aClassConstraint_894;
    private static String aString895;
    private static boolean aBoolean896;
    private static String aString897;


    public static void method1773(String var0) {
        aString897 = var0;
    }

    public static void method1774(String var0) {
        aString895 = var0;
    }

    public static void method1775(boolean var0) {
        aBoolean896 = var0;
    }

    public static boolean method1776() {
        return aBoolean896;
    }

    public static ClassConstraint method1777() {
        return aClassConstraint_894;
    }

    public static String method1778() {
        return aString895;
    }

    public static void method1779(ClassConstraint var0) {
        aClassConstraint_894 = var0;
    }

    public static String method1780() {
        return aString897;
    }
}
