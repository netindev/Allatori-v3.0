package com.allatori;


public class Class167 {

    private static boolean aBoolean855 = false;
    private static String aString856;
    private static String aString857;


    public static String method1656() {
        return aString856;
    }

    public static void method1657(String var0) {
        aString857 = var0;
    }

    public static void method1658(String var0) {
        aString856 = var0;
    }

    public static boolean method1659() {
        return aBoolean855;
    }

    public static String method1660() {
        return aString857;
    }

    public static void method1661(boolean var0) {
        aBoolean855 = var0;
    }
}
