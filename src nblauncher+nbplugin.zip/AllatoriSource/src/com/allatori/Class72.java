package com.allatori;

import java.util.Vector;

public class Class72 {

    private static Vector aVector645 = new Vector();


    public static Vector method832() {
        return aVector645;
    }

    public static void method833(String var0) {
        aVector645.add(var0);
    }

}
