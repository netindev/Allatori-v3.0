package com.allatori;

public class ObfuscationTypeConstraint {

    public int type;
    public ClassConstraint classConstraint;


    public ObfuscationTypeConstraint(int type, ClassConstraint var2) {
        this.type = type;
        this.classConstraint = var2;
    }
}
