package com.allatori;


public class Class57 {

    private static String aString613;


    public static void setLogFile(String var0) {
        aString613 = var0;
    }

    public static String method710() {
        return aString613;
    }
}
