package com.allatori;

public class Class69 implements Interface22 {

    private String aString1156;


    public Class69() {
        this.aString1156 = "a";
    }

    public void method263() {
    }

    public String method262() {
        return this.aString1156;
    }
}
