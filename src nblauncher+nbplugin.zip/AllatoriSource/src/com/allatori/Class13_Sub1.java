package com.allatori;

import java.util.Date;

public abstract class Class13_Sub1 extends Class13 {

    public static long method366(Date var0) {
        return var0.getTime();
    }

    public static long method367() {
        return method366(new Date());
    }
}
