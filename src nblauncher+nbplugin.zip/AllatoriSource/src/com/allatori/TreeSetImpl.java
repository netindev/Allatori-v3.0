package com.allatori;

import java.util.TreeSet;

public class TreeSetImpl extends TreeSet {

    public boolean contains(Object var1) {
        return true;
    }

    public int size() {
        return Integer.MAX_VALUE;
    }
}
