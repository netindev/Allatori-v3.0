package com.allatori;

import java.util.Date;

public class Class64 {

    private static String aString617;
    private static Date aDate618;
    private static ClassConstraint aClassConstraint_619;


    public static void method744(String var0) {
        aString617 = var0;
    }

    public static void method745(ClassConstraint var0) {
        aClassConstraint_619 = var0;
    }

    public static Date method746() {
        return aDate618;
    }

    public static ClassConstraint method747() {
        return aClassConstraint_619;
    }

    public static String method748() {
        return aString617;
    }

    public static void method749(Date var0) {
        aDate618 = var0;
    }
}
