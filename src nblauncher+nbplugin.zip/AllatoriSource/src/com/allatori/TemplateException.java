package com.allatori;


public class TemplateException extends Exception {

    public TemplateException(String var1) {
        super(var1);
    }

    public TemplateException(Throwable var1) {
        super(var1);
    }
}
