package com.allatori;

import java.util.Vector;

public class Class45 {

    private static Vector aVector596 = new Vector();
    private static String aString597 = null;
    private static Vector aVector598 = new Vector();


    public static String method655() {
        return aString597;
    }

    public static void method656(Class149 var0) {
        aVector596.add(var0);
    }

    public static Vector method657() {
        return aVector598;
    }

    public static void method658(String var0) {
        aString597 = var0;
    }

    public static void method659(Class157 var0) {
        aVector598.add(var0);
    }

    public static Vector method660() {
        return aVector596;
    }
}
