package com.allatori;


public class Class118 {

    public String aString734;
    public String aString735;


    public Class118(String var1, String var2) {
        this.aString734 = var1;
        this.aString735 = var2;
    }
}
