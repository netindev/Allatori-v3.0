package com.allatori;

import java.io.Serializable;

public class Class7 implements Cloneable, Serializable {

    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
}
