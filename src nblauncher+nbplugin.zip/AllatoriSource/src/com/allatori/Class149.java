package com.allatori;


public class Class149 {

    public String aString799;
    public String aString800;


    public Class149(String var1, String var2) {
        this.aString799 = var1;
        this.aString800 = var2;
    }
}
