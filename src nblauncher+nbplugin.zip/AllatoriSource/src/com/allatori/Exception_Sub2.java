package com.allatori;


public class Exception_Sub2 extends Exception {

}
