package com.allatori;


public class LineNumbers {

    public static final int anInt545 = 2;
    private static int anInt546 = 1;
    public static final int anInt547 = 1;
    public static final int anInt548 = 3;


    public static int method454() {
        return anInt546;
    }

    public static void setLineNumberType(int var0) {
        anInt546 = var0;
    }
}
