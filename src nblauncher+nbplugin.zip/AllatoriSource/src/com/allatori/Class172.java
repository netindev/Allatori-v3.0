package com.allatori;

public class Class172 {

    private Class141 aClass141_871;
    private NameRepository aNameRepository_873;
    private Class156 aClass156_874;
    private Class159 aClass159_875;
    private Class165 aClass165_876;


    // $FF: synthetic method
    public static NameRepository method1707(Class172 var0) {
        return var0.aNameRepository_873;
    }

    // $FF: synthetic method
    public static Class165 method1708(Class172 var0) {
        return var0.aClass165_876;
    }

    private Class172(Renamer var1) {
        Renamer aRenamer_872 = var1;
        this.aClass141_871 = new Class141(this, null);
        this.aClass165_876 = new Class165(this, null);
        this.aNameRepository_873 = new NameRepository(this, null);
        this.aClass159_875 = new Class159(this, null);
        this.aClass156_874 = new Class156(this, null);
    }

    // $FF: synthetic method
    public Class172(Renamer var1, Class178 var2) {
        this(var1);
    }

    // $FF: synthetic method
    public static Class156 method1709(Class172 var0) {
        return var0.aClass156_874;
    }

    // $FF: synthetic method
    public static Class159 method1710(Class172 var0) {
        return var0.aClass159_875;
    }

    // $FF: synthetic method
    public static Class141 method1711(Class172 var0) {
        return var0.aClass141_871;
    }
}
