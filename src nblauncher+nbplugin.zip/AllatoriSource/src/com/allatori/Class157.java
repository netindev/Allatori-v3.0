package com.allatori;


public class Class157 {

    public String aString811;
    public String aString812;


    public Class157(String var1, String var2) {
        this.aString811 = var1;
        this.aString812 = var2;
    }
}
