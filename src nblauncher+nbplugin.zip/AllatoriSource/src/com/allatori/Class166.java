package com.allatori;

import java.util.Vector;

public class Class166 {

    public RenamingMap aRenamingMap_852;
    public Vector aVector853;
    public RenamingMap aRenamingMap_854;


}
