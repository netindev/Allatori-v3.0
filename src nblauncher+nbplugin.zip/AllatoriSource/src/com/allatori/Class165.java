package com.allatori;

public class Class165 {

    private RenamingMap aRenamingMap_847;
    private RenamingMap aRenamingMap_849;
    private Interface22 anInterface22_850;
    private RenamingMap aRenamingMap_851;


    // $FF: synthetic method
    public static RenamingMap method1652(Class165 var0) {
        return var0.aRenamingMap_849;
    }

    private Class165(Class172 var1) {
        Class172 aClass172_848 = var1;
        this.anInterface22_850 = Unknown.method339();
        this.aRenamingMap_847 = new RenamingMap();
        this.aRenamingMap_851 = new RenamingMap();
        this.aRenamingMap_849 = new RenamingMap();
    }

    // $FF: synthetic method
    public static RenamingMap method1653(Class165 var0) {
        return var0.aRenamingMap_847;
    }

    // $FF: synthetic method
    public Class165(Class172 var1, Class178 var2) {
        this(var1);
    }

    // $FF: synthetic method
    public static Interface22 method1654(Class165 var0) {
        return var0.anInterface22_850;
    }

    // $FF: synthetic method
    public static RenamingMap method1655(Class165 var0) {
        return var0.aRenamingMap_851;
    }
}
