package com.allatori;


public class Exception_Sub1 extends Exception {

    public Exception_Sub1(String var1) {
        super(var1);
    }
}
