package com.allatori;

public interface Interface26 {

    void parse() throws TemplateException;
}
