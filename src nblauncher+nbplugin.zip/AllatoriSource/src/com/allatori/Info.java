package com.allatori;


public class Info {

    public static String website() {
        return "http://www.allatori.com";
    }

    public static String version() {
        return "v3.0 DEMO";
    }

    public static String name() {
        return "Allatori Obfuscator";
    }
}
