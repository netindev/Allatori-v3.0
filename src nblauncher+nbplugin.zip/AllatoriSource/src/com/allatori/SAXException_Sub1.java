package com.allatori;

import org.xml.sax.SAXException;

public class SAXException_Sub1 extends SAXException {

    public SAXException_Sub1(String var1) {
        super(var1);
    }
}
