package com.allatori;

public abstract class Property {

}
