package com.allatori;


public interface Interface22 {

    String method262();

    void method263();
}
