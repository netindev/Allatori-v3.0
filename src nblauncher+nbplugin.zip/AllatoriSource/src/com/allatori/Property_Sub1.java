package com.allatori;

public class Property_Sub1 extends Property {

}
