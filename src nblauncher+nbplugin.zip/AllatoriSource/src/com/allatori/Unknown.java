package com.allatori;

public class Unknown {

    public static final int anInt517 = 1;
    private static int anInt518 = 2;
    private static int anInt519 = 2;
    public static final int anInt520 = 3;
    public static final int anInt521 = 2;


    public static void setMethodNamingType(int var0) {
        anInt518 = var0;
    }

    public static Interface22 method333() {
        return anInt518 == 1 ? new Class113() : (anInt518 == 3 ? new Class94_Sub1() : new Class105());
    }

    public static Interface22 method334() {
        return new Class113();
    }

    public static Interface22 method335() {
        return new Class113();
    }

    public static Interface22 method336() {
        return anInt519 == 1 ? new Class113() : (anInt519 == 3 ? new Class94_Sub1() : new Class105());
    }

    public static Interface22 method337() {
        return LocalVariables.method372() == 2 ? new Class113() : (LocalVariables.method372() == 1 ? new Class69() : new Class113());
    }

    public static void setFieldNamingType(int i) {
        anInt519 = i;
    }

    public static Interface22 method339() {
        return new Class113();
    }

}
