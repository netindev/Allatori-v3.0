package com.allatori;

public class Class159 {

    private Interface22 anInterface22_814;
    private RenamingMap aRenamingMap_815;
    private RenamingMap aRenamingMap_816;
    private RenamingMap aRenamingMap_818;


    // $FF: synthetic method
    public static RenamingMap method1625(Class159 var0) {
        return var0.aRenamingMap_818;
    }

    // $FF: synthetic method
    public Class159(Class172 var1, Class178 var2) {
        this(var1);
    }

    // $FF: synthetic method
    public static RenamingMap method1626(Class159 var0) {
        return var0.aRenamingMap_815;
    }

    // $FF: synthetic method
    public static Interface22 method1627(Class159 var0) {
        return var0.anInterface22_814;
    }

    private Class159(Class172 var1) {
        Class172 aClass172_817 = var1;
        this.anInterface22_814 = Unknown.method336();
        this.aRenamingMap_815 = new RenamingMap();
        this.aRenamingMap_818 = new RenamingMap();
        this.aRenamingMap_816 = new RenamingMap();
    }

    // $FF: synthetic method
    public static RenamingMap method1628(Class159 var0) {
        return var0.aRenamingMap_816;
    }
}
