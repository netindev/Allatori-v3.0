package com.allatori;

public class Class141 {

    private RenamingMap aRenamingMap_781;
    private RenamingMap aRenamingMap_782;
    private Interface22 anInterface22_783;


    // $FF: synthetic method
    public static RenamingMap method1520(Class141 var0) {
        return var0.aRenamingMap_782;
    }

    // $FF: synthetic method
    public static Interface22 method1521(Class141 var0) {
        return var0.anInterface22_783;
    }

    private Class141(Class172 var1) {
        Class172 aClass172_784 = var1;
        this.anInterface22_783 = Unknown.method335();
        this.aRenamingMap_782 = new RenamingMap();
        this.aRenamingMap_781 = new RenamingMap();
    }

    // $FF: synthetic method
    public static RenamingMap method1522(Class141 var0) {
        return var0.aRenamingMap_781;
    }

    // $FF: synthetic method
    public Class141(Class172 var1, Class178 var2) {
        this(var1);
    }
}
