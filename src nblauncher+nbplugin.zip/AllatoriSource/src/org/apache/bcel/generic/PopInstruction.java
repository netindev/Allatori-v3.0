package org.apache.bcel.generic;

public interface PopInstruction extends StackConsumer {
}
