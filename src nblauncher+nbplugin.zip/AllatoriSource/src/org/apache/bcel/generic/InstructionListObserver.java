package org.apache.bcel.generic;

public interface InstructionListObserver {
	public void notify(InstructionList instructionlist);
}
