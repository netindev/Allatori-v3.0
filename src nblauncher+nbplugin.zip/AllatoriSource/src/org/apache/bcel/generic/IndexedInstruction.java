package org.apache.bcel.generic;

public interface IndexedInstruction {
	public int getIndex();

	public void setIndex(int i);
}
