package org.apache.bcel.generic;

public interface StackConsumer {
	public int consumeStack(ConstantPoolGen constantpoolgen);
}
