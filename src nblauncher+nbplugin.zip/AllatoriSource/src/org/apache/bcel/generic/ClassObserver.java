package org.apache.bcel.generic;

public interface ClassObserver {
	public void notify(ClassGen classgen);
}
