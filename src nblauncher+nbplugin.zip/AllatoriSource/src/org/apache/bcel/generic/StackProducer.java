package org.apache.bcel.generic;

public interface StackProducer {
	public int produceStack(ConstantPoolGen constantpoolgen);
}
