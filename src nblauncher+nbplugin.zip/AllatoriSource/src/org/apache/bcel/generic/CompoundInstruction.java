package org.apache.bcel.generic;

public interface CompoundInstruction {
	public InstructionList getInstructionList();
}
