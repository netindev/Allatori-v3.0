package org.apache.bcel.generic;

public interface TypedInstruction {
	public Type getType(ConstantPoolGen constantpoolgen);
}
