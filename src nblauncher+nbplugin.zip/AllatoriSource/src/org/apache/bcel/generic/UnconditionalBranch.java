package org.apache.bcel.generic;

public interface UnconditionalBranch {
}
