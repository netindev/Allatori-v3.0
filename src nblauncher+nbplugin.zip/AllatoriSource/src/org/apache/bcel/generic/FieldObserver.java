package org.apache.bcel.generic;

public interface FieldObserver {
	public void notify(FieldGen fieldgen);
}
