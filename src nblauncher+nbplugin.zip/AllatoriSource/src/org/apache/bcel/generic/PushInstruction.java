package org.apache.bcel.generic;

public interface PushInstruction extends StackProducer {
}
