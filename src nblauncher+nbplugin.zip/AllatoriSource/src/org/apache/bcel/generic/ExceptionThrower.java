package org.apache.bcel.generic;

public interface ExceptionThrower {
	public Class[] getExceptions();
}
