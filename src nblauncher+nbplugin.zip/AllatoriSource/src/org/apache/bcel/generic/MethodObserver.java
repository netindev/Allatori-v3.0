package org.apache.bcel.generic;

public interface MethodObserver {
	public void notify(MethodGen methodgen);
}
