package org.apache.bcel.util;

public interface BCELComparator {
	public boolean equals(Object object0, Object object1);

	public int hashCode(Object object);
}
