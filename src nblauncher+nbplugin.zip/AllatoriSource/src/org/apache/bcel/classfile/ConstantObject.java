package org.apache.bcel.classfile;

public interface ConstantObject {
	public Object getConstantValue(ConstantPool constantpool);
}
